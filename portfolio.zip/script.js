
// Loader
window.addEventListener('load', () => {
  const loader = document.getElementById('loader');
  loader.style.opacity = '0';
  loader.style.visibility = 'hidden';
  loader.style.transition = 'opacity 0.5s ease';
});

// Apparition au scroll
document.addEventListener('DOMContentLoaded', () => {
  const observer = new IntersectionObserver((entries) => {
    entries.forEach(entry => {
      if(entry.isIntersecting) {
        entry.target.classList.add('show');
      }
    });
  }, { threshold: 0.1 });

  document.querySelectorAll('.project-card, .skills-list li').forEach((el) => observer.observe(el));
});

// Menu mobile
const burger = document.querySelector('.burger');
const nav = document.querySelector('.nav-links');

if(burger && nav){
  burger.addEventListener('click', () => {
    nav.classList.toggle('nav-active');
  });
}

// Transition entre pages
const links = document.querySelectorAll('a');

links.forEach(link => {
  link.addEventListener('click', function(e) {
    const target = this.getAttribute('href');
    if (target && target.startsWith('#') === false) {
      e.preventDefault();
      document.body.classList.add('fade-out');
      setTimeout(() => {
        window.location.href = target;
      }, 500);
    }
  });
});

// Fade-in au chargement
window.addEventListener('DOMContentLoaded', () => {
  document.body.classList.add('fade-in');
});
